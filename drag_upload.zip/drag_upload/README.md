# Drag &amp; Drop Uploader

**Drag &amp; Drop Uploader** to prosty, modułowy system umożliwiający
przeciąganie i upuszczanie plików lub całych folderów bezpośrednio z
Twojego komputera do przeglądarki internetowej, a następnie ich
przesłanie na serwer. Projekt zawiera zarówno nowoczesny interfejs
klienta (HTML, CSS i JavaScript), jak i prosty skrypt PHP obsługujący
stronę serwerową. Dzięki wtyczkom można w przyszłości wzbogacić go
o dodatkowe funkcje (szyfrowanie, kompresja ZIP, linki jednorazowe itp.).

## Funkcje

- **Przeciąganie i upuszczanie** plików oraz całych folderów. Obsługiwane
  są zarówno pojedyncze pliki, jak i wielopoziomowe struktury katalogów.
- **Rozpoznawanie formatów** – w tabeli wyników wyświetlane są nazwa,
  rozszerzenie, rozmiar w kilobajtach oraz ścieżka względna każdego
  przesłanego elementu.
- **Paski postępu** dla każdego przesyłanego pliku, aktualizowane w
  czasie rzeczywistym podczas ładowania.
- **Tryb automatyczny** – po zaznaczeniu opcji „Tryb automatycznego
  ładowania” pliki są wysyłane natychmiast po dodaniu do listy.
- **Zapisywanie zorganizowane** – po stronie serwera tworzony jest
  podkatalog z datą i godziną przesyłki, w którym zapisywane są
  przesłane pliki z zachowaniem struktury folderów. Dodatkowo
  generowany jest plik `file_list.txt` zawierający listę nazw i
  rozmiarów przesłanych elementów.
- **Modułowa architektura wtyczek** – przygotowane szkielety ułatwiają
  rozbudowę systemu o kolejne funkcje, np. szyfrowanie danych,
  kompresję ZIP, generowanie jednorazowych linków, integrację z
  systemami w chmurze lub API AI.

## Struktura projektu

```
drag_upload/
├── index.html           # główna strona z interfejsem użytkownika
├── style.css            # arkusz stylów odpowiadający za wygląd
├── script.js            # logika obsługi drag‑and‑drop i wysyłania
├── upload.php           # skrypt PHP zapisujący pliki na serwerze
├── uploads/             # katalog, w którym zapisywane są przesłane pliki
│   └── .gitignore       # ignoruje przesłane pliki w repozytorium
├── plugins/             # moduły rozszerzające (szyfrowanie, ZIP, linki)
│   ├── encryption.php   # szkielet wtyczki szyfrującej
│   ├── zip.php          # szkielet wtyczki kompresującej
│   ├── links.php        # szkielet wtyczki generującej linki
│   └── README.md        # opis mechanizmu wtyczek
└── README.md            # ten plik
```

## Jak uruchomić projekt

### Za pomocą wbudowanego serwera PHP

1. Upewnij się, że masz zainstalowane PHP w wersji 7.4 lub wyższej.
2. Otwórz terminal w katalogu `drag_upload`.
3. Uruchom wbudowany serwer: `php -S localhost:8000`.
4. Odwiedź w przeglądarce adres `http://localhost:8000/index.html`.
5. Przeciągnij pliki lub foldery na wyznaczoną strefę, ewentualnie
   kliknij w pole, aby je wybrać. Naciśnij przycisk „Wyślij pliki”,
   jeśli tryb automatyczny nie jest włączony.
6. Po zakończeniu przesyłania zajrzyj do katalogu `uploads/`, aby
   zobaczyć utworzony podkatalog z nazwą w formacie daty.

### Za pomocą XAMPP lub innego serwera PHP

1. Skopiuj cały katalog `drag_upload` do folderu `htdocs` w Twojej
   instalacji XAMPP (lub odpowiedniego katalogu hostowanego przez
   serwer Apache).
2. Uruchom Apache w XAMPP.
3. Wejdź na `http://localhost/drag_upload/index.html`.
4. Reszta przebiega tak samo jak w przypadku wbudowanego serwera.

## Pomysły na przyszłe integracje

Projekt powstał z myślą o rozbudowie. Oto kilka pomysłów na kolejne
funkcje i integracje:

1. **Szyfrowanie plików** – integracja z biblioteką OpenSSL w PHP lub
   Web Crypto API w JavaScript, aby zabezpieczyć dane podczas
   przesyłania i przechowywania.
2. **Kompresja ZIP** – możliwość pakowania kilku plików w jedno
   archiwum przed pobraniem lub przesłaniem do chmury.
3. **Jednorazowe linki** – generowanie unikalnych tokenów
   umożliwiających pobranie przesłanych plików bez logowania.
4. **Integracja z chmurą** – wysyłanie przesłanych plików bezpośrednio
   do usług takich jak Amazon S3, Google Drive czy Nextcloud.
5. **Moduł AI** – analiza i klasyfikacja przesyłanych plików, np.
   wykrywanie typów plików, szacowanie treści (obrazy/dokumenty) czy
   automatyczne generowanie opisów.
6. **Autoryzacja użytkowników** – panel logowania i uprawnienia,
   umożliwiające ograniczenie dostępu do przesyłania i pobierania.
7. **Integracja z Pythonem/Node.js** – wtyczki wykonywane po stronie
   serwera w innych językach, np. do przetwarzania danych binarnych.

Jeżeli masz własny pomysł na wtyczkę lub usprawnienie — dołącz do
projektu, stwórz własną gałąź i stwórz pull request!

## Wkład i współpraca

Serdecznie zapraszamy wszystkich do współpracy! Jeśli znajdziesz
błędy, masz sugestie czy chcesz rozbudować system o nową funkcję,
zachęcamy do otwierania zgłoszeń w trackerze (issues) oraz pull
requestów. Poniższe kroki pomogą Ci rozpocząć:

1. **Fork repozytorium** na swoim koncie GitHub.
2. **Stwórz nową gałąź** na potrzeby zmian (`git checkout -b feature/nazwa`).
3. Dokonaj zmian i upewnij się, że projekt wciąż działa (lokalne testy).
4. **Zgłoś pull request** opisujący, co zmieniono i dlaczego.
5. Uczestnicz w dyskusji w komentarzach — wspólnie dopracujemy Twoje
   rozwiązanie!

Każda forma kontrybucji jest mile widziana, również zgłaszanie błędów
czy pomysłów. Razem możemy stworzyć rozbudowane narzędzie do
przesyłania plików i folderów z wieloma praktycznymi integracjami.